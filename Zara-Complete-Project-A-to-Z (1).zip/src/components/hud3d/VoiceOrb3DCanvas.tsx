import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

interface VoiceOrb3DCanvasProps {
  isListening: boolean;
  isSpeaking: boolean;
  isThinking?: boolean;
  micVolume?: number;
  sizePx?: number;
  className?: string;
}

const _dummyObj = new THREE.Object3D();
const _tmpColor = new THREE.Color();
const _barColorIdle = new THREE.Color(0xfb7185);
const _barColorListen = new THREE.Color(0x10b981);
const _barColorSpeak = new THREE.Color(0x0ea5e9);
const _barColorThink = new THREE.Color(0xf59e0b);

export const VoiceOrb3DCanvas: React.FC<VoiceOrb3DCanvasProps> = ({
  isListening,
  isSpeaking,
  isThinking = false,
  micVolume = 0,
  sizePx = 220,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const stateRef = useRef({
    isListening,
    isSpeaking,
    isThinking,
    micVolume,
  });

  useEffect(() => {
    stateRef.current = { isListening, isSpeaking, isThinking, micVolume };
  }, [isListening, isSpeaking, isThinking, micVolume]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || typeof window === 'undefined') return;

    const isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas');
        const gl = probe.getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param) || '');
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      return;
    }

    const width = Math.max(120, container.clientWidth || sizePx);
    const height = Math.max(120, container.clientHeight || sizePx);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height, false);
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.pointerEvents = 'none';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 40);
    camera.position.set(0, 0.15, 5.4);
    camera.lookAt(0, 0, 0);

    const pmrem = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmrem.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmrem.dispose();

    // Warm key + cool hemisphere studio rig (<= 2 lights)
    const hemiLight = new THREE.HemisphereLight(0xbae6fd, 0x1e1b4b, 1.1);
    scene.add(hemiLight);
    const keyLight = new THREE.DirectionalLight(0xfff1f2, 1.8);
    keyLight.position.set(3, 4, 4);
    scene.add(keyLight);

    const rootGroup = new THREE.Group();
    scene.add(rootGroup);

    // 1. Primary Core Glass Shell + Inner Neural Energy Core
    const outerShellGeo = new THREE.IcosahedronGeometry(1.18, 2);
    const outerShellMat = new THREE.MeshPhysicalMaterial({
      color: 0xe0f2fe,
      metalness: 0.12,
      roughness: 0.14,
      transmission: isSoftwareGl ? 0 : 0.72,
      transparent: true,
      opacity: isSoftwareGl ? 0.24 : 0.85,
      ior: 1.45,
      clearcoat: 1.0,
      depthWrite: false,
    });
    const outerShellMesh = new THREE.Mesh(outerShellGeo, outerShellMat);
    outerShellMesh.renderOrder = 2;
    rootGroup.add(outerShellMesh);

    const coreGeo = new THREE.OctahedronGeometry(0.62, 1);
    const coreMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0ea5e9,
      emissiveIntensity: 0.75,
      metalness: 0.35,
      roughness: 0.42,
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    rootGroup.add(coreMesh);

    // 2. Dual Machined Gyroscopic Gimbal Rings (contrasting roughness/metalness)
    const ringOuterGeo = new THREE.TorusGeometry(1.56, 0.036, 12, 64);
    const ringOuterMat = new THREE.MeshStandardMaterial({
      color: 0xf43f5e,
      emissive: 0x9f1239,
      emissiveIntensity: 0.3,
      metalness: 0.92,
      roughness: 0.18,
    });
    const ringOuter = new THREE.Mesh(ringOuterGeo, ringOuterMat);
    ringOuter.rotation.x = Math.PI * 0.28;
    rootGroup.add(ringOuter);

    const ringInnerGeo = new THREE.TorusGeometry(1.38, 0.026, 12, 56);
    const ringInnerMat = new THREE.MeshStandardMaterial({
      color: 0x7dd3fc,
      emissive: 0x0284c7,
      emissiveIntensity: 0.35,
      metalness: 0.65,
      roughness: 0.46,
    });
    const ringInner = new THREE.Mesh(ringInnerGeo, ringInnerMat);
    ringInner.rotation.y = Math.PI * 0.35;
    rootGroup.add(ringInner);

    // 3. 24-Bar Radial Spatial Equalizer Ring (InstancedMesh)
    const barCount = 24;
    const barGeo = new THREE.BoxGeometry(0.055, 0.24, 0.055);
    const barMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0x0ea5e9,
      emissiveIntensity: 0.55,
      metalness: 0.45,
      roughness: 0.28,
    });
    const equalizerMesh = new THREE.InstancedMesh(barGeo, barMat, barCount);
    equalizerMesh.frustumCulled = false;
    rootGroup.add(equalizerMesh);

    if (!isSoftwareGl) {
      try {
        renderer.compile(scene, camera);
      } catch {}
    }

    let disposed = false;
    let isVisible = true;
    let isDocVisible = typeof document === 'undefined' || document.visibilityState === 'visible';
    let frameId = 0;
    let lastTime = performance.now();
    let smoothedEnergy = 0.1;
    let phase = 0;

    const handleResize = () => {
      if (disposed || !container) return;
      const w = Math.max(120, container.clientWidth || sizePx);
      const h = Math.max(120, container.clientHeight || sizePx);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h, false);
    };

    const resizeObserver =
      typeof ResizeObserver !== 'undefined' ? new ResizeObserver(handleResize) : null;
    resizeObserver?.observe(container);

    const intersectionObserver =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisible = Boolean(entries[0]?.isIntersecting ?? true);
              if (isVisible && isDocVisible && !frameId) {
                lastTime = performance.now();
                scheduleNext();
              }
            },
            { threshold: 0.05 }
          )
        : null;
    intersectionObserver?.observe(container);

    const onVisibilityChange = () => {
      isDocVisible = document.visibilityState === 'visible';
      if (isVisible && isDocVisible && !frameId) {
        lastTime = performance.now();
        scheduleNext();
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);

    function afterDraw(cb: () => void) {
      try {
        const gl = renderer.getContext() as WebGL2RenderingContext;
        if (!gl || typeof gl.fenceSync !== 'function') {
          frameId = window.setTimeout(cb, 80);
          return;
        }
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (disposed) {
            if (sync) gl.deleteSync(sync);
            return;
          }
          const state = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      } catch {
        frameId = window.setTimeout(cb, 80);
      }
    }

    function scheduleNext() {
      if (disposed || !isVisible || !isDocVisible) {
        frameId = 0;
        return;
      }
      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = window.requestAnimationFrame(tick);
      }
    }

    function tick() {
      frameId = 0;
      if (disposed || !isVisible || !isDocVisible) return;

      const now = performance.now();
      const dt = Math.min(0.08, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;

      const st = stateRef.current;
      const micNorm = Math.min(1, Math.max(0, (st.micVolume || 0) / 85));
      const targetEnergy = st.isSpeaking
        ? 0.55 + Math.sin(now * 0.011) * 0.22 + micNorm * 0.25
        : st.isThinking
        ? 0.42 + Math.sin(now * 0.008) * 0.14
        : st.isListening
        ? 0.2 + micNorm * 0.78
        : 0.08;

      smoothedEnergy = THREE.MathUtils.damp(smoothedEnergy, targetEnergy, 8.5, dt);
      phase += dt * (st.isThinking ? 2.4 : st.isSpeaking ? 1.85 : st.isListening ? 1.25 : 0.45);

      const targetAccent = st.isThinking
        ? _barColorThink
        : st.isSpeaking
        ? _barColorSpeak
        : st.isListening
        ? _barColorListen
        : _barColorIdle;

      coreMat.color.lerp(targetAccent, Math.min(1, dt * 6));
      coreMat.emissive.lerp(targetAccent, Math.min(1, dt * 6));
      coreMat.emissiveIntensity = THREE.MathUtils.damp(
        coreMat.emissiveIntensity,
        0.5 + smoothedEnergy * 1.15,
        7,
        dt
      );
      ringOuterMat.emissive.lerp(targetAccent, Math.min(1, dt * 5));
      barMat.emissive.lerp(targetAccent, Math.min(1, dt * 6));

      coreMesh.rotation.y += dt * (0.9 + smoothedEnergy * 1.8);
      coreMesh.rotation.x += dt * 0.45;
      const pulseScale = 1 + smoothedEnergy * 0.16;
      coreMesh.scale.setScalar(pulseScale);
      outerShellMesh.rotation.y -= dt * 0.35;

      ringOuter.rotation.z += dt * (0.55 + smoothedEnergy * 0.9);
      ringOuter.rotation.y = Math.sin(phase * 0.7) * 0.38;
      ringInner.rotation.x += dt * (0.75 + smoothedEnergy * 1.1);
      ringInner.rotation.z -= dt * 0.42;

      const eqRadius = 1.78 + smoothedEnergy * 0.1;
      for (let i = 0; i < barCount; i++) {
        const angle = (i / barCount) * Math.PI * 2 + phase * 0.25;
        const harmonic =
          0.35 +
          Math.abs(Math.sin(phase * 2.2 + i * 0.65)) * 0.65 +
          Math.abs(Math.cos(phase * 1.4 - i * 0.35)) * 0.35;
        const barScaleY = 0.45 + smoothedEnergy * 1.85 * harmonic;

        _dummyObj.position.set(
          Math.cos(angle) * eqRadius,
          Math.sin(angle) * eqRadius,
          Math.sin(angle * 2 + phase) * 0.08
        );
        _dummyObj.rotation.set(0, 0, angle - Math.PI / 2);
        _dummyObj.scale.set(1, barScaleY, 1);
        _dummyObj.updateMatrix();
        equalizerMesh.setMatrixAt(i, _dummyObj.matrix);

        _tmpColor.copy(targetAccent).multiplyScalar(0.75 + Math.min(0.5, barScaleY * 0.2));
        equalizerMesh.setColorAt(i, _tmpColor);
      }
      equalizerMesh.instanceMatrix.needsUpdate = true;
      if (equalizerMesh.instanceColor) equalizerMesh.instanceColor.needsUpdate = true;

      renderer.render(scene, camera);
      scheduleNext();
    }

    tick();

    return () => {
      disposed = true;
      if (frameId) {
        window.cancelAnimationFrame(frameId);
        window.clearTimeout(frameId);
      }
      resizeObserver?.disconnect();
      intersectionObserver?.disconnect();
      document.removeEventListener('visibilitychange', onVisibilityChange);

      outerShellGeo.dispose();
      outerShellMat.dispose();
      coreGeo.dispose();
      coreMat.dispose();
      ringOuterGeo.dispose();
      ringOuterMat.dispose();
      ringInnerGeo.dispose();
      ringInnerMat.dispose();
      barGeo.dispose();
      barMat.dispose();
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [sizePx]);

  return (
    <div
      ref={containerRef}
      aria-hidden="true"
      className={`pointer-events-none select-none ${className}`}
      style={{ width: sizePx, height: sizePx }}
    />
  );
};

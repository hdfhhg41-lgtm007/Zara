import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bell,
  BookOpen,
  Brain,
  Calendar,
  CloudRain,
  ExternalLink,
  Heart,
  Home,
  Lock,
  MessageSquare,
  Mic,
  MoreVertical,
  Music,
  Paperclip,
  Pencil,
  PhoneCall,
  PhoneOff,
  Radar,
  Send,
  ShieldCheck,
  SkipForward,
  Sun,
  Thermometer,
  Volume2,
  Zap,
} from 'lucide-react';
import moonStarsOrbImg from '../../assets/images/zara_moon_stars_orb_1794848874066.jpg';
import { audioService } from '../../services/audioService';
import { VoiceOrb3DCanvas } from './VoiceOrb3DCanvas';
import {
  ChatMessage,
  Language,
  PersonalityConfig,
  SecurityAndControlConfig,
  ZaraEmotionMode,
} from '../../types';

interface ZaraSciFi3DHudDashboardProps {
  isSpeaking: boolean;
  isListening: boolean;
  isThinking?: boolean;
  micVolume?: number;
  interimTranscript?: string;
  subtitleText: string;
  voiceError?: string | null;
  onDismissVoiceError?: () => void;
  messages: ChatMessage[];
  config: PersonalityConfig;
  onUpdateConfig: (updates: Partial<PersonalityConfig>) => void;
  onSendMessage: (text: string, attachedImageDataUrl?: string) => Promise<string>;
  onSendAudioWav?: (wavBase64: string, mimeType?: string) => Promise<void>;
  onToggleMic: () => void;
  onSkipVoiceTurn?: () => void;
  onEnableAllFunctions?: () => Promise<void>;
  allFunctionsActive?: boolean;
  isAudioCallOpen?: boolean;
  onOpenAudioCall?: () => void;
  onOpenSettings: () => void;
  onOpenNotifications?: () => void;
  unreadNotificationsCount?: number;
  securityConfig?: SecurityAndControlConfig;
  isOwnerVerified?: boolean;
  language?: Language;
  onOpenSecurity?: () => void;
  onOpenPermissions?: () => void;
  onOpenChat?: () => void;
  onOpenAiStudio?: (tab?: any) => void;
  onLockPhoneNow?: () => void;
  onGrantAllPermissions?: () => Promise<void>;
  antiTouchArmed?: boolean;
  onOpenMemories?: () => void;
  onOpenSkills?: () => void;
  onOpenCharacter?: () => void;
  onSwitchToStudioMode?: () => void;
  onSelectLanguage?: (lang: Language) => void;
  userNickname?: string;
  visionMode?: 'off' | 'camera' | 'screen';
  cameraFacing?: 'user' | 'environment';
  onStartCamera?: () => void;
  onStopCamera?: () => void;
  onToggleScreenShare?: () => void;
  onOpenDriverMode?: () => void;
  onOpenFileManager?: () => void;
  batteryTelemetry?: { pct: number | null; tempC: number | null; charging: boolean | null };
  onScanSurroundings?: () => void;
  onOpenWhatsAppDigest?: () => void;
}

interface WeatherSummary {
  tempC: number;
  condition: string;
  humidity: number;
  isRain: boolean;
}

const EMOTION_LABELS: Record<ZaraEmotionMode, { title: string; subtitle: string }> = {
  pyar: { title: 'Pyaar', subtitle: 'Sab badhiya' },
  apnapan: { title: 'Apnapan', subtitle: 'Dil se paas' },
  calm: { title: 'Shant', subtitle: 'Sukoon hai' },
  emotional: { title: 'Bhaavuk', subtitle: 'Dil ki baat' },
  gussa: { title: 'Gussa', subtitle: 'Thoda tez' },
  narazgi: { title: 'Naraz', subtitle: 'Mana lo' },
  ladai: { title: 'Tez', subtitle: 'Nok-jhok' },
};

const QUICK_STARTERS = [
  { label: 'السلام علیکم زارا، آج کا موسم کیسا ہے؟', caption: 'Urdu' },
  { label: 'ज़ारा, मेरी स्क्रीन या सवाल का जवाब बोलकर बताओ', caption: 'Hindi' },
  { label: 'Summarize how you can help me today', caption: 'English' },
];

function decodeWmoWeather(code: number): { label: string; isRain: boolean } {
  if (code === 0) return { label: 'Clear', isRain: false };
  if (code <= 3) return { label: 'Partly Cloudy', isRain: false };
  if (code <= 48) return { label: 'Misty', isRain: false };
  if (code <= 67 || (code >= 80 && code <= 82)) return { label: 'Showers', isRain: true };
  if (code >= 95) return { label: 'Storm', isRain: true };
  return { label: 'Breezy', isRain: false };
}

function getGreetingForHour(hour: number): string {
  if (hour >= 22 || hour < 4) return 'Abhi tak jaag rahe ho,';
  if (hour >= 4 && hour < 12) return 'Subah bakhair,';
  if (hour >= 12 && hour < 17) return 'Din kaisa ja raha hai,';
  return 'Shaam bakhair,';
}

const RADIAL_TICK_VECTORS = Array.from({ length: 60 }, (_, i) => {
  const angle = (i / 60) * Math.PI * 2;
  const cos = Math.cos(angle);
  const sin = Math.sin(angle);
  const waveBoost = i % 3 === 0 ? 5 : i % 2 === 0 ? 2 : 0;
  return {
    i,
    cos,
    sin,
    waveBoost,
    x1: 100 + cos * 76,
    y1: 100 + sin * 76,
  };
});

export const ZaraSciFi3DHudDashboard: React.FC<ZaraSciFi3DHudDashboardProps> = React.memo(({
  isSpeaking,
  isListening,
  isThinking = false,
  micVolume = 0,
  interimTranscript = '',
  subtitleText,
  voiceError = null,
  onDismissVoiceError,
  messages,
  config,
  onSendMessage,
  onToggleMic,
  onSkipVoiceTurn,
  onEnableAllFunctions,
  allFunctionsActive = false,
  isAudioCallOpen = false,
  onOpenAudioCall,
  onOpenSettings,
  onOpenNotifications,
  unreadNotificationsCount = 0,
  isOwnerVerified = false,
  language = 'auto',
  onOpenChat,
  onOpenAiStudio,
  onOpenMemories,
  onOpenCharacter,
  userNickname,
  batteryTelemetry,
  onScanSurroundings,
  onOpenWhatsAppDigest,
}) => {
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isEnablingAll, setIsEnablingAll] = useState(false);
  const [activeNav, setActiveNav] = useState<'home' | 'audio_call' | 'yaadein' | 'chat'>('home');
  const [weather, setWeather] = useState<WeatherSummary>({
    tempC: 24,
    condition: 'Clear',
    humidity: 62,
    isRain: false,
  });

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const desktopChatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    desktopChatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, interimTranscript, isThinking]);

  // Fetch real live weather without prompting intrusive browser permission dialogs
  useEffect(() => {
    let cancelled = false;
    const loadWeather = async (lat: number, lon: number) => {
      try {
        const res = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,weather_code`
        );
        if (!res.ok) return;
        const data = await res.json();
        const cur = data?.current;
        if (!cur || cancelled) return;
        const decoded = decodeWmoWeather(Number(cur.weather_code ?? 0));
        setWeather({
          tempC: Math.round(Number(cur.temperature_2m ?? 24)),
          condition: decoded.label,
          humidity: Math.round(Number(cur.relative_humidity_2m ?? 60)),
          isRain: decoded.isRain,
        });
      } catch {}
    };

    const fallbackLat = 24.8607;
    const fallbackLon = 67.0011;

    if (typeof navigator !== 'undefined' && navigator.permissions?.query) {
      navigator.permissions
        .query({ name: 'geolocation' as PermissionName })
        .then((perm) => {
          if (perm.state === 'granted' && navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
              (pos) => loadWeather(pos.coords.latitude, pos.coords.longitude),
              () => loadWeather(fallbackLat, fallbackLon),
              { timeout: 5000 }
            );
          } else {
            loadWeather(fallbackLat, fallbackLon);
          }
        })
        .catch(() => loadWeather(fallbackLat, fallbackLon));
    } else {
      loadWeather(fallbackLat, fallbackLon);
    }

    return () => {
      cancelled = true;
    };
  }, []);

  const now = useMemo(() => new Date(), []);
  const dayNumber = now.getDate();
  const shortWeekdayMonth = useMemo(
    () =>
      now.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
      }),
    [now]
  );
  const greetingLine = useMemo(() => getGreetingForHour(now.getHours()), [now]);
  const displayNickname = (userNickname || config.userNickname || 'Dost').trim() || 'Dost';

  const isHeartLocked = Boolean(config.heartLockEnabled && !config.heartLockUnlocked);
  const activeEmotion: ZaraEmotionMode = isHeartLocked
    ? 'calm'
    : config.emotionMode || 'apnapan';
  const emotionCard = EMOTION_LABELS[activeEmotion] || EMOTION_LABELS.apnapan;

  const isCallActive = isListening || isSpeaking || isThinking;
  const ringAccentColor = isListening
    ? '#10b981'
    : isSpeaking
    ? '#0ea5e9'
    : '#fb7185';
  const pulseIntensity = isSpeaking
    ? 1
    : isListening
    ? Math.max(0.25, Math.min(1, micVolume / 60))
    : 0.15;

  const latestReplyMessage = useMemo(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].sender !== 'user') return messages[i];
    }
    return null;
  }, [messages]);

  const handleSendText = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const text = inputText.trim();
    if (!text || isSending) return;
    setInputText('');
    setIsSending(true);
    audioService.unlock();
    try {
      await onSendMessage(text);
    } finally {
      setIsSending(false);
    }
  };

  const handlePhotoPicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!dataUrl) return;
      audioService.unlock();
      setIsSending(true);
      try {
        await onSendMessage(
          inputText.trim() || 'Is tasveer ko dekh kar batao ismein kya hai?',
          dataUrl
        );
        setInputText('');
      } finally {
        setIsSending(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleActivateAllClick = async () => {
    if (!onEnableAllFunctions || isEnablingAll) return;
    audioService.unlock();
    setIsEnablingAll(true);
    try {
      await onEnableAllFunctions();
    } finally {
      setIsEnablingAll(false);
    }
  };

  const handleCenterCallVoiceToggle = () => {
    audioService.unlock();
    onToggleMic();
  };

  // Compute 60 radial ticks from precomputed unit vectors (zero trig per render)
  const radialTicks = useMemo(() => {
    const scaleFactor = 0.4 + pulseIntensity * 0.9;
    return RADIAL_TICK_VECTORS.map((v) => {
      const outerR = 88 + v.waveBoost * scaleFactor;
      return {
        i: v.i,
        x1: v.x1,
        y1: v.y1,
        x2: 100 + v.cos * outerR,
        y2: 100 + v.sin * outerR,
      };
    });
  }, [pulseIntensity]);

  return (
    <div className="relative w-full min-h-screen bg-gradient-to-b from-[#dce8fb] via-[#e7f0fd] to-[#cddff8] text-slate-900 overflow-x-hidden flex flex-col">
      {/* Subtle Daylight Atmospheric Topographic Lines */}
      <svg
        aria-hidden="true"
        className="fixed inset-0 w-full h-full pointer-events-none opacity-35"
        viewBox="0 0 430 932"
        preserveAspectRatio="xMidYMid slice"
      >
        <circle cx="240" cy="400" r="190" fill="none" stroke="#9db9e8" strokeWidth="1" />
        <circle cx="240" cy="400" r="260" fill="none" stroke="#a8c2ec" strokeWidth="0.9" />
        <path
          d="M-30 560 Q 75 510, 145 450 T 310 385 T 470 330"
          fill="none"
          stroke="#95b4e6"
          strokeWidth="1.2"
        />
        <path
          d="M-40 610 Q 95 570, 190 500 T 360 440 T 480 410"
          fill="none"
          stroke="#adc7ee"
          strokeWidth="1"
        />
      </svg>

      {/* Hidden Photo Attachment Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handlePhotoPicked}
        className="hidden"
      />

      {/* Responsive Wrapper: Mobile Portrait Match + Desktop 2-Column Balance */}
      <div className="relative z-10 flex-1 w-full max-w-6xl mx-auto px-4 pt-3 pb-24 lg:pb-6 lg:py-5 grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* PRIMARY MOBILE / LEFT STAGE */}
        <div className="lg:col-span-5 flex flex-col justify-between gap-3.5 max-w-[460px] w-full mx-auto">
          {/* 1. TOP HEADER BAR: 3-DOT SETTINGS + ZARA BRAND + NOTIFICATION BELL */}
          <header className="h-12 flex items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={onOpenSettings}
                className="w-11 h-11 rounded-full bg-white/95 hover:bg-white shadow-[0_6px_18px_rgba(30,64,120,0.12)] border border-white flex items-center justify-center text-slate-800 cursor-pointer transition-transform active:scale-95 shrink-0"
                aria-label="Open All Zara Settings"
                title="All Settings (Voice, Android, AI, Security)"
              >
                <MoreVertical className="w-5 h-5" />
              </button>
              <span className="text-2xl font-extrabold tracking-tight text-slate-900 whitespace-nowrap">
                Zara
              </span>
            </div>

            <button
              type="button"
              onClick={onOpenNotifications || onOpenSettings}
              className="relative w-11 h-11 rounded-full bg-white/95 hover:bg-white shadow-[0_6px_18px_rgba(30,64,120,0.12)] border border-white flex items-center justify-center text-slate-800 cursor-pointer transition-transform active:scale-95 shrink-0"
              aria-label="Notifications & Spoken Alerts"
              title="Notifications & Spoken Alerts"
            >
              <Bell className="w-5 h-5" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-white" />
              )}
            </button>
          </header>

          {/* 2. FROSTED PERIWINKLE ALL-SYSTEMS / LICENSE BANNER */}
          <div className="rounded-2xl bg-[#c9defb]/85 border border-white/75 backdrop-blur-md px-3.5 py-2.5 shadow-[0_4px_14px_rgba(30,64,120,0.06)] flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-white/70 flex items-center justify-center text-sky-600 shrink-0">
                {allFunctionsActive || isOwnerVerified ? (
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                ) : (
                  <Lock className="w-4 h-4 text-sky-600" />
                )}
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-slate-900 truncate">
                  {allFunctionsActive
                    ? 'All Systems ON · Voice & Android Ready'
                    : isOwnerVerified
                    ? 'Owner Verified · Full AI Mode Ready'
                    : 'Zara Smart Mode · 6 Assistants & Phone Control'}
                </div>
                <div className="text-[11px] text-slate-600 truncate">
                  Saare tools aur continuous voice call ke liye activate karein
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={allFunctionsActive ? onOpenSettings : handleActivateAllClick}
              disabled={isEnablingAll}
              className="min-h-[36px] px-3 py-1.5 rounded-xl bg-white/90 hover:bg-white text-xs font-extrabold text-slate-900 shadow-sm whitespace-nowrap shrink-0 cursor-pointer transition-colors"
            >
              {isEnablingAll ? 'Activating...' : allFunctionsActive ? 'Active ✓' : 'Activate karo'}
            </button>
          </div>

          {/* 3. GREETING HEADLINE + RIGHT QUICK SYSTEMS TOGGLE CARD */}
          <div className="flex items-center justify-between gap-3 px-0.5">
            <div className="min-w-0">
              <p className="text-lg sm:text-xl font-bold text-slate-800 leading-snug">
                {greetingLine}
              </p>
              <h1
                className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight truncate"
                style={{ textWrap: 'balance' } as React.CSSProperties}
              >
                {displayNickname}
              </h1>
            </div>

            <button
              type="button"
              onClick={handleActivateAllClick}
              disabled={isEnablingAll}
              className="min-h-[48px] px-3.5 py-2 rounded-2xl bg-white/92 hover:bg-white shadow-[0_8px_20px_rgba(30,64,120,0.09)] border border-white flex items-center gap-2 shrink-0 cursor-pointer transition-transform active:scale-95"
              title="Tap to turn All Zara Functions ON"
            >
              <Zap
                className={`w-4 h-4 shrink-0 ${
                  allFunctionsActive ? 'text-emerald-500 fill-emerald-500' : 'text-amber-500 fill-amber-500'
                }`}
              />
              <div className="text-left leading-tight">
                <div className="text-xs font-extrabold text-slate-900 whitespace-nowrap">
                  {allFunctionsActive ? 'All ON' : 'Boost'}
                </div>
                <div className="text-[10px] font-medium text-slate-500 whitespace-nowrap">
                  {isCallActive ? 'Call Live' : 'Systems'}
                </div>
              </div>
            </button>
          </div>

          {/* 4. CENTERPIECE: 3D COMPOSITE VOICE ORB + MOON & STARS APERTURE */}
          <div className="flex flex-col items-center justify-center py-1">
            <div className="relative w-[206px] h-[206px] sm:w-[224px] sm:h-[224px] flex items-center justify-center">
              {/* Interactive Three.js 3D Voice Orb & Spatial Equalizer */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <VoiceOrb3DCanvas
                  isListening={isListening}
                  isSpeaking={isSpeaking}
                  isThinking={isThinking}
                  micVolume={micVolume}
                  sizePx={216}
                />
              </div>

              {/* Radial waveform tick dial SVG */}
              <svg
                aria-hidden="true"
                viewBox="0 0 200 200"
                className="absolute inset-0 w-full h-full pointer-events-none opacity-65"
              >
                {radialTicks.map((t) => (
                  <line
                    key={t.i}
                    x1={t.x1}
                    y1={t.y1}
                    x2={t.x2}
                    y2={t.y2}
                    stroke={ringAccentColor}
                    strokeWidth={t.i % 3 === 0 ? '1.6' : '1.1'}
                    strokeOpacity={isCallActive ? '0.85' : '0.45'}
                    strokeLinecap="round"
                  />
                ))}
              </svg>

              {/* Circular Aperture with Crescent Moon & Stars Artwork (zero robot picture) */}
              <button
                type="button"
                onClick={handleCenterCallVoiceToggle}
                aria-label="Tap Zara Moon & Stars Orb to toggle voice"
                className={`relative z-10 w-[112px] h-[112px] sm:w-[122px] sm:h-[122px] rounded-full bg-[#09080f] overflow-hidden border-[3px] shadow-[0_0_28px_rgba(244,63,94,0.28)] transition-[transform,border-color,box-shadow] duration-150 ease-out will-change-transform cursor-pointer ${
                  isListening
                    ? 'border-emerald-400 shadow-[0_0_32px_rgba(16,185,129,0.45)]'
                    : isSpeaking
                    ? 'border-sky-400 shadow-[0_0_32px_rgba(14,165,233,0.45)]'
                    : 'border-rose-400/80'
                }`}
                style={{
                  transform: `translate3d(0,0,0) scale(${(1 + pulseIntensity * 0.045).toFixed(4)})`,
                }}
              >
                <img
                  src={moonStarsOrbImg}
                  alt="Zara Cosmic Moon & Stars Orb"
                  className="w-full h-full object-cover scale-[1.34]"
                />
              </button>
            </div>

            {/* Concise live status + clear visible voice error banner below orb */}
            <div className="mt-1.5 flex flex-col items-center justify-center gap-1.5 max-w-full px-2">
              <div className="flex items-center justify-center gap-2 max-w-full">
                <p className="text-xs font-medium text-slate-700 text-center truncate max-w-[300px]">
                  {interimTranscript
                    ? /^(🎤|📡|Awake)/i.test(interimTranscript)
                      ? interimTranscript
                      : language === 'english'
                      ? `Listening: "${interimTranscript}"`
                      : language === 'hindi'
                      ? `सुन रही हूँ: "${interimTranscript}"`
                      : language === 'punjabi'
                      ? `ਸੁਣ ਰਹੀ ਆਂ: "${interimTranscript}"`
                      : `سن رہی ہوں: "${interimTranscript}"`
                    : isThinking
                    ? language === 'english'
                      ? 'Processing voice & thinking...'
                      : language === 'hindi'
                      ? 'आवाज़ समझ रही हूँ...'
                      : language === 'punjabi'
                      ? 'ਤੁਹਾਡੀ ਗੱਲ ਸਮਝ ਰਹੀ ਆਂ...'
                      : 'آواز سمجھ رہی ہوں...'
                    : isSpeaking
                    ? language === 'english'
                      ? 'Zara speaking — listening resumes next...'
                      : language === 'hindi'
                      ? 'ज़ारा बोल रही है — सुनना जारी रहेगा...'
                      : language === 'punjabi'
                      ? 'ਜ਼ਾਰਾ ਬੋਲ ਰਹੀ ਐ — ਫਿਰ ਸੁਣਾਂਗੀ...'
                      : 'زارا بول رہی ہے — سننا جاری رہے گا...'
                    : isListening
                    ? language === 'english'
                      ? 'Voice ON — Speak naturally anytime'
                      : language === 'hindi'
                      ? 'वॉइस चालू है — आराम से बोलें'
                      : language === 'punjabi'
                      ? 'ਵਾਇਸ ਚਾਲੂ ਐ — ਆਰਾਮ ਨਾਲ ਬੋਲੋ'
                      : 'وائس آن ہے — آرام سے بولیں'
                    : subtitleText ||
                      (language === 'english'
                        ? 'Tap the voice button once to start'
                        : language === 'hindi'
                        ? 'शुरू करने के लिए वॉइस बटन एक बार दबाएँ'
                        : language === 'punjabi'
                        ? 'ਸ਼ੁਰੂ ਕਰਨ ਲਈ ਵਾਇਸ ਬਟਨ ਇੱਕ ਵਾਰ ਦਬਾਓ'
                        : 'شروع کرنے کے لیے وائس بٹن ایک بار دبائیں')}
                </p>
                {(isListening || isSpeaking || isThinking) && (
                  <button
                    type="button"
                    onClick={() => {
                      audioService.unlock();
                      if (onSkipVoiceTurn) {
                        onSkipVoiceTurn();
                      } else {
                        audioService.stopAudio(true);
                      }
                    }}
                    aria-label="Skip current turn and keep listening"
                    className={`min-h-[30px] px-3 rounded-xl text-[11px] font-bold flex items-center gap-1.5 shrink-0 cursor-pointer shadow-sm transition-colors ${
                      isSpeaking || isThinking
                        ? 'bg-sky-600 hover:bg-sky-500 text-white'
                        : 'bg-white/95 hover:bg-white text-slate-700 border border-sky-200'
                    }`}
                  >
                    <SkipForward className="w-3.5 h-3.5" />
                    <span>Skip</span>
                  </button>
                )}
              </div>

              {voiceError && (
                <div
                  role="alert"
                  className="w-full max-w-[340px] px-3 py-1.5 rounded-xl bg-rose-50 border border-rose-300 text-rose-800 text-[11px] font-semibold flex items-center justify-between gap-2 shadow-sm"
                >
                  <span className="leading-snug text-left">{voiceError}</span>
                  {onDismissVoiceError && (
                    <button
                      type="button"
                      onClick={onDismissVoiceError}
                      className="text-rose-500 hover:text-rose-800 font-bold px-1 shrink-0 cursor-pointer"
                      aria-label="Dismiss voice error"
                    >
                      ✕
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* 5. THREE HORIZONTAL QUICK-ACTION PILLS (GAANE, STUDIO, JOURNAL) */}
          <div className="grid grid-cols-3 gap-2.5">
            <button
              type="button"
              onClick={() => {
                audioService.unlock();
                onSendMessage('Zara mere mood ke hisaab se pyaare gaane suggest karo');
              }}
              className="min-h-[46px] px-3 rounded-2xl bg-white/92 hover:bg-white shadow-[0_6px_18px_rgba(30,64,120,0.08)] border border-white text-xs font-bold text-slate-800 flex items-center justify-center gap-1.5 cursor-pointer transition-transform active:scale-95"
            >
              <Music className="w-4 h-4 text-sky-600 shrink-0" />
              <span className="truncate">Gaane</span>
            </button>

            <button
              type="button"
              onClick={() => (onOpenAiStudio ? onOpenAiStudio('office') : onOpenSettings())}
              className="min-h-[46px] px-3 rounded-2xl bg-white/92 hover:bg-white shadow-[0_6px_18px_rgba(30,64,120,0.08)] border border-white text-xs font-bold text-slate-800 flex items-center justify-center gap-1.5 cursor-pointer transition-transform active:scale-95"
            >
              <BookOpen className="w-4 h-4 text-sky-600 shrink-0" />
              <span className="truncate">Padhai</span>
            </button>

            <button
              type="button"
              onClick={() => (onOpenMemories ? onOpenMemories() : onOpenSettings())}
              className="min-h-[46px] px-3 rounded-2xl bg-white/92 hover:bg-white shadow-[0_6px_18px_rgba(30,64,120,0.08)] border border-white text-xs font-bold text-slate-800 flex items-center justify-center gap-1.5 cursor-pointer transition-transform active:scale-95"
            >
              <Pencil className="w-4 h-4 text-sky-600 shrink-0" />
              <span className="truncate">Journal</span>
            </button>
          </div>

          {/* 6. THREE-COLUMN FROSTED INFO BENTO CARDS (MAUSAM, AAJ, MOOD) */}
          <div className="grid grid-cols-3 gap-2.5">
            {/* Mausam Card */}
            <button
              type="button"
              onClick={() => {
                audioService.unlock();
                onSendMessage('Aaj ka mausam kaisa hai?');
              }}
              className="text-left p-3 rounded-3xl bg-white/90 hover:bg-white shadow-[0_8px_22px_rgba(30,64,120,0.08)] border border-white flex flex-col justify-between min-h-[104px] cursor-pointer transition-transform active:scale-[0.98]"
            >
              <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-600">
                {weather.isRain ? (
                  <CloudRain className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                ) : (
                  <Sun className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                )}
                <span className="truncate">Mausam</span>
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-950 tabular-nums leading-tight">
                  {weather.tempC}°
                </div>
                <div className="text-[11px] font-medium text-slate-600 truncate">
                  {weather.condition}
                </div>
              </div>
              <div className="text-[10px] font-bold text-slate-500 tabular-nums">
                {weather.humidity}% humidity
              </div>
            </button>

            {/* Aaj Date Card */}
            <button
              type="button"
              onClick={() => (onOpenNotifications ? onOpenNotifications() : onOpenSettings())}
              className="text-left p-3 rounded-3xl bg-white/90 hover:bg-white shadow-[0_8px_22px_rgba(30,64,120,0.08)] border border-white flex flex-col justify-between min-h-[104px] cursor-pointer transition-transform active:scale-[0.98]"
            >
              <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-600">
                <Calendar className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                <span className="truncate">Aaj</span>
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-950 tabular-nums leading-tight">
                  {dayNumber}
                </div>
                <div className="text-[11px] font-medium text-slate-600 truncate">
                  {shortWeekdayMonth}
                </div>
              </div>
              <div className="text-[10px] font-semibold text-sky-600 truncate">Alarms · Schedule</div>
            </button>

            {/* Mood Card */}
            <button
              type="button"
              onClick={() => (onOpenCharacter ? onOpenCharacter() : onOpenSettings())}
              className="relative overflow-hidden text-left p-3 rounded-3xl bg-white/90 hover:bg-white shadow-[0_8px_22px_rgba(30,64,120,0.08)] border border-white flex flex-col justify-between min-h-[104px] cursor-pointer transition-transform active:scale-[0.98]"
            >
              <Heart
                aria-hidden="true"
                className="absolute right-1.5 bottom-4 w-12 h-12 text-rose-300/45 fill-rose-300/35 pointer-events-none"
              />
              <div className="relative flex items-center gap-1 text-[11px] font-semibold text-slate-600">
                <Heart className="w-3.5 h-3.5 text-slate-700 fill-slate-700 shrink-0" />
                <span className="truncate">Mood</span>
              </div>
              <div className="relative">
                <div className="text-lg font-extrabold text-slate-950 leading-tight truncate">
                  {emotionCard.title}
                </div>
                <div className="text-[11px] font-medium text-slate-600 truncate">
                  {emotionCard.subtitle}
                </div>
              </div>
              <div className="relative text-[10px] font-semibold text-rose-500 truncate">
                Tap to change
              </div>
            </button>
          </div>

          {/* Surroundings Perception & Battery Thermal Strip */}
          <div className="rounded-2xl bg-white/85 border border-white px-3 py-2 shadow-[0_4px_14px_rgba(30,64,120,0.06)] flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <Thermometer
                className={`w-4 h-4 shrink-0 ${
                  batteryTelemetry?.tempC !== null &&
                  batteryTelemetry?.tempC !== undefined &&
                  batteryTelemetry.tempC >= 40
                    ? 'text-rose-600'
                    : 'text-sky-600'
                }`}
              />
              <div className="min-w-0 text-[11px] font-semibold text-slate-700 truncate tabular-nums">
                <span>
                  {weather.tempC}°C · {weather.condition}
                </span>
                {batteryTelemetry?.pct !== null && batteryTelemetry?.pct !== undefined && (
                  <span className="ml-2 text-slate-500">
                    • {batteryTelemetry.pct}%
                    {batteryTelemetry.tempC !== null && batteryTelemetry.tempC !== undefined
                      ? ` (${batteryTelemetry.tempC.toFixed(1)}°C)`
                      : ''}
                    {batteryTelemetry.charging ? ' ⚡' : ''}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              {onOpenWhatsAppDigest && (
                <button
                  type="button"
                  onClick={() => {
                    audioService.unlock();
                    onOpenWhatsAppDigest();
                  }}
                  className="px-2.5 py-1 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 text-[10px] font-bold cursor-pointer whitespace-nowrap"
                >
                  30s Digest
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  audioService.unlock();
                  if (onScanSurroundings) {
                    onScanSurroundings();
                  } else {
                    onSendMessage('Scan surroundings');
                  }
                }}
                className="px-2.5 py-1 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-[10px] font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <Radar className="w-3 h-3 shrink-0" />
                <span>Scan</span>
              </button>
            </div>
          </div>

          {/* Mobile Compact Reply Strip (only when there is a reply and not on lg desktop) */}
          {latestReplyMessage && (
            <div className="lg:hidden rounded-2xl bg-white/75 backdrop-blur-md border border-white px-3.5 py-2 shadow-sm flex items-center justify-between gap-2">
              <p className="text-xs text-slate-800 line-clamp-2 flex-1">
                <span className="font-bold text-sky-700">Zara: </span>
                {latestReplyMessage.text}
              </p>
              <button
                type="button"
                onClick={() => {
                  audioService.unlock();
                  audioService.speakText(latestReplyMessage.text, {
                    language,
                    voiceName: config.voiceName,
                    loveMode: config.loveMode,
                    emotionMode: activeEmotion,
                  });
                }}
                className="w-9 h-9 rounded-full bg-sky-50 hover:bg-sky-100 text-sky-700 flex items-center justify-center shrink-0 cursor-pointer"
                aria-label="Replay last Zara message"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* 7. FROSTED ASK INPUT PILL ("Zara se kuch bhi poochho...") */}
          <form
            onSubmit={handleSendText}
            className="rounded-full bg-white/85 backdrop-blur-md shadow-[0_8px_22px_rgba(30,64,120,0.09)] border border-white px-2 py-1.5 flex items-center gap-1.5"
          >
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-10 h-10 rounded-full hover:bg-slate-100 text-slate-500 hover:text-slate-800 flex items-center justify-center shrink-0 cursor-pointer transition-colors"
              aria-label="Attach photo for Zara Vision"
              title="Attach image"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Zara se kuch bhi poochho..."
              className="flex-1 min-w-0 bg-transparent text-sm text-slate-900 placeholder:text-slate-500 font-medium focus:outline-none px-1"
            />

            <button
              type="submit"
              disabled={!inputText.trim() || isSending}
              className="w-10 h-10 rounded-full bg-white hover:bg-sky-50 text-sky-600 disabled:text-slate-300 shadow-[0_3px_10px_rgba(30,64,120,0.12)] border border-slate-100 flex items-center justify-center shrink-0 cursor-pointer transition-colors"
              aria-label="Send Message to Zara"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          {/* 8. BOTTOM 5-SLOT NAVIGATION BAR WITH ONE CENTER CALL-STYLE TWO-WAY VOICE BUTTON */}
          <nav
            aria-label="Primary Navigation"
            className="fixed bottom-3 left-1/2 -translate-x-1/2 z-40 w-[calc(100%-1.5rem)] max-w-[440px] lg:static lg:translate-x-0 lg:w-full lg:max-w-full lg:mt-2"
          >
            <div className="relative h-[66px] rounded-[28px] bg-white/95 backdrop-blur-xl shadow-[0_12px_32px_rgba(30,64,120,0.16)] border border-white px-2 grid grid-cols-5 items-center">
              {/* Tab 1: Home */}
              <button
                type="button"
                onClick={() => {
                  setActiveNav('home');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`min-h-[48px] mx-0.5 rounded-2xl flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors ${
                  activeNav === 'home'
                    ? 'bg-gradient-to-b from-[#66aaff] to-[#3b82f6] text-white shadow-sm'
                    : 'text-slate-700 hover:bg-slate-100/70'
                }`}
              >
                <Home className="w-[18px] h-[18px]" />
                <span className="text-[10px] font-bold leading-none">Home</span>
              </button>

              {/* Tab 2: Audio Call */}
              <button
                type="button"
                onClick={() => {
                  setActiveNav('audio_call');
                  audioService.unlock();
                  onOpenAudioCall?.();
                }}
                className={`min-h-[48px] mx-0.5 rounded-2xl flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors ${
                  isAudioCallOpen
                    ? 'bg-emerald-100 text-emerald-700 shadow-sm'
                    : 'text-slate-700 hover:bg-slate-100/70'
                }`}
                title="Open HD Audio Call (with background Keep mode)"
              >
                <PhoneCall className="w-[18px] h-[18px]" />
                <span className="text-[10px] font-bold leading-none whitespace-nowrap">
                  {isAudioCallOpen ? 'Call Live' : 'Audio Call'}
                </span>
              </button>

              {/* Tab 3 (CENTER): SINGLE TWO-WAY CALL-LIKE VOICE BUTTON (LISTEN + REPLY) */}
              <div className="relative flex flex-col items-center justify-center">
                <button
                  type="button"
                  onClick={handleCenterCallVoiceToggle}
                  aria-label={
                    isCallActive
                      ? 'End Two-Way Voice Call with Zara'
                      : 'Start Two-Way Voice Call with Zara'
                  }
                  title={
                    isCallActive
                      ? 'Call ON — Tap to end voice conversation'
                      : 'Tap once — Zara listens & speaks back like a live call'
                  }
                  className={`-mt-6 w-[66px] h-[66px] rounded-full p-1.5 flex items-center justify-center cursor-pointer transition-transform active:scale-95 shadow-[0_10px_26px_rgba(59,130,246,0.45)] ${
                    isListening
                      ? 'bg-gradient-to-b from-emerald-400 to-teal-500 ring-4 ring-emerald-200/80'
                      : isSpeaking
                      ? 'bg-gradient-to-b from-sky-400 to-blue-600 ring-4 ring-sky-200/80'
                      : isThinking
                      ? 'bg-gradient-to-b from-amber-400 to-orange-500 ring-4 ring-amber-200/80'
                      : 'bg-gradient-to-b from-[#7cb8ff] to-[#3b82f6] ring-4 ring-white/90'
                  }`}
                >
                  <span className="w-full h-full rounded-full bg-white flex items-center justify-center shadow-inner">
                    {isCallActive ? (
                      <PhoneCall
                        className={`w-6 h-6 ${
                          isListening
                            ? 'text-emerald-600'
                            : isSpeaking
                            ? 'text-blue-600'
                            : 'text-amber-600'
                        }`}
                      />
                    ) : (
                      <Mic className="w-6 h-6 text-[#3b82f6]" />
                    )}
                  </span>
                </button>
                {isCallActive && (
                  <span className="text-[9px] font-extrabold text-emerald-700 leading-none mt-0.5 whitespace-nowrap">
                    {isSpeaking ? 'Speaking' : isThinking ? 'Thinking' : 'Voice ON'}
                  </span>
                )}
              </div>

              {/* Tab 4: Yaadein (Memories) */}
              <button
                type="button"
                onClick={() => {
                  setActiveNav('yaadein');
                  onOpenMemories ? onOpenMemories() : onOpenSettings();
                }}
                className="min-h-[48px] mx-0.5 rounded-2xl flex flex-col items-center justify-center gap-0.5 text-slate-700 hover:bg-slate-100/70 cursor-pointer transition-colors"
              >
                <Brain className="w-[18px] h-[18px]" />
                <span className="text-[10px] font-bold leading-none">Yaadein</span>
              </button>

              {/* Tab 5: Chat */}
              <button
                type="button"
                onClick={() => {
                  setActiveNav('chat');
                  onOpenChat ? onOpenChat() : onOpenSettings();
                }}
                className="min-h-[48px] mx-0.5 rounded-2xl flex flex-col items-center justify-center gap-0.5 text-slate-700 hover:bg-slate-100/70 cursor-pointer transition-colors"
              >
                <MessageSquare className="w-[18px] h-[18px]" />
                <span className="text-[10px] font-bold leading-none">Chat</span>
              </button>
            </div>
          </nav>
        </div>

        {/* DESKTOP RIGHT PANEL: LIVE MESSAGES, AUDIO REPLAY & VOICE PROMPTS */}
        <section className="hidden lg:flex lg:col-span-7 flex-col rounded-3xl bg-white/85 backdrop-blur-lg border border-white shadow-[0_12px_36px_rgba(30,64,120,0.09)] overflow-hidden max-h-[calc(100vh-3rem)]">
          <div className="px-5 py-4 border-b border-slate-200/70 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="text-base font-extrabold text-slate-900">
                Zara Conversation &amp; Voice Replies
              </span>
              <span className="text-xs font-semibold text-slate-500 tabular-nums">
                · {messages.length}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCenterCallVoiceToggle}
                className={`min-h-[38px] px-3.5 rounded-full text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors ${
                  isCallActive
                    ? 'bg-emerald-500 text-white shadow-sm'
                    : 'bg-sky-500 hover:bg-sky-600 text-white shadow-sm'
                }`}
              >
                {isCallActive ? (
                  <>
                    <PhoneOff className="w-3.5 h-3.5" />
                    <span>End Two-Way Call</span>
                  </>
                ) : (
                  <>
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Start Two-Way Call</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={onOpenSettings}
                className="min-h-[38px] px-3 rounded-full bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-800 flex items-center gap-1.5 cursor-pointer"
              >
                <MoreVertical className="w-3.5 h-3.5" />
                <span>All Settings</span>
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-5 space-y-3.5 select-text">
            {messages.length <= 1 && (
              <div className="rounded-2xl bg-sky-50/90 border border-sky-200/70 p-4 space-y-2.5">
                <p className="text-xs font-bold text-slate-800">
                  Quick prompts to test Zara:
                </p>
                <div className="grid grid-cols-1 gap-2">
                  {QUICK_STARTERS.map((q) => (
                    <button
                      key={q.caption}
                      type="button"
                      onClick={() => {
                        audioService.unlock();
                        onSendMessage(q.label);
                      }}
                      className="min-h-[42px] px-3.5 py-2 rounded-xl bg-white hover:bg-sky-100/60 border border-sky-100 text-left text-xs font-medium text-slate-800 flex items-center justify-between gap-2 cursor-pointer transition-colors"
                    >
                      <span className="truncate">{q.label}</span>
                      <span className="text-[11px] font-bold text-sky-600 shrink-0">
                        {q.caption}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((m) => {
              const isUser = m.sender === 'user';
              return (
                <div
                  key={m.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] px-4 py-2.5 rounded-2xl ${
                      isUser
                        ? 'bg-gradient-to-br from-[#5aa2ff] to-[#3b82f6] text-white rounded-br-sm shadow-sm'
                        : 'bg-white border border-slate-200/80 text-slate-900 rounded-bl-sm shadow-sm'
                    }`}
                  >
                    {m.imageUrl && (
                      <img
                        src={m.imageUrl}
                        alt="Message attachment"
                        referrerPolicy="no-referrer"
                        className="w-full max-h-52 object-cover rounded-xl mb-2"
                      />
                    )}
                    <p className="whitespace-pre-wrap leading-relaxed text-sm">{m.text}</p>
                    {Array.isArray(m.sources) && m.sources.length > 0 && (
                      <div className="mt-2 pt-2 border-t border-slate-200/70 flex flex-wrap gap-2">
                        {m.sources.slice(0, 3).map((src, idx) => (
                          <a
                            key={`${m.id}-src-${idx}`}
                            href={src.url}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[11px] text-sky-600 hover:underline inline-flex items-center gap-1"
                          >
                            <ExternalLink className="w-3 h-3 shrink-0" />
                            <span className="truncate max-w-[180px]">{src.title || 'Source'}</span>
                          </a>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 mt-1 px-1 text-[11px] text-slate-500">
                    <span>{isUser ? 'You' : m.assistantLabel || 'Zara'}</span>
                    <span>·</span>
                    <span className="tabular-nums">{m.timestamp}</span>
                    {!isUser && (
                      <>
                        <span>·</span>
                        <button
                          type="button"
                          onClick={() => {
                            audioService.unlock();
                            audioService.speakText(m.text, {
                              language,
                              voiceName: config.voiceName,
                              loveMode: config.loveMode,
                              emotionMode: activeEmotion,
                            });
                          }}
                          className="text-sky-600 hover:text-sky-700 font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>Sunao</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}

            {isThinking && (
              <div className="flex items-start">
                <div className="px-4 py-2.5 rounded-2xl rounded-bl-sm bg-white border border-slate-200 text-xs font-medium text-slate-600 shadow-sm">
                  Zara soch rahi hai aur jawab taiyaar kar rahi hai...
                </div>
              </div>
            )}

            <div ref={desktopChatEndRef} />
          </div>
        </section>
      </div>
    </div>
  );
});
